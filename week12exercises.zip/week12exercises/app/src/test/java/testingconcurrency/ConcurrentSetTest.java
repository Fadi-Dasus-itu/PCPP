package testingconcurrency;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
// TODO: Very likely you need to expand the list of imports

public class ConcurrentSetTest {

    // Variable with set under test
    private ConcurrentIntegerSet set;

    // TODO: Very likely you should add more variables here


    // Uncomment the appropriate line below to choose the class to
    // test
    // Remember that @BeforeEach is executed before each test
    @BeforeEach
    public void initialize() {
        // init set
//        set = new ConcurrentIntegerSetBuggy();
        // set = new ConcurrentIntegerSetSync();
        set = new ConcurrentIntegerSetLibrary();
    }

    //------------------- 1 ------------------
    @Test
    void addElementsToTheSetConcurrentlyFails() throws InterruptedException {
        Thread t = new Thread(() -> {
            for (int i = 0; i < 1000; i++) {
                set.add(i);
            }
        });
        Thread t2 = new Thread(() -> {
            for (int i = 1000; i < 2000; i++) {
                set.add(i);
            }
        });

        t.start();
        t2.start();
        t.join();
        t2.join();
        // size should be 2000
        Assertions.assertTrue(set.size() == 2000);
    }


    //------------------- 2 ------------------
    //------------------- 3 ------------------
    // by synchronizing the access to the set, we ensure mutual exclusive access to add and remove methods, thus no bad interleaving will occur
    @Test
    @RepeatedTest(1000)
    @DisplayName("the interleaving in which the test fails is when multiple threads access the counter that is associated with the size variable " +
            "in the set, and since updating the size is not atomic(read, modify, write) then we are risking duplicated decrement in the size variable")
    void removeElementsFromTheSetConcurrentlyFails() throws InterruptedException {
        //arrange --------------------------
        set.add(1);

        var barrier = new CyclicBarrier(41);
        ExecutorService executor = Executors.newFixedThreadPool(40);
        for (int i = 0; i < 40; i++) {
            executor.execute(() -> {
                //act ---------------------------------
                try {
                    barrier.await();
                    for (int j = 0; j < 40; j++) {
                        var s = set.remove(1);
                    }
                    barrier.await();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (BrokenBarrierException e) {
                    e.printStackTrace();
                }
            });
        }

        try {
            barrier.await();
            barrier.await();

        } catch (BrokenBarrierException e) {
            e.printStackTrace();
        }
        // assert -----------------------------
        Assertions.assertEquals(set.size(), 0);

    }


    //---------------- 4 ------------------
    // running the test using ConcurrentIntegerSetLibrary will not fail since
    // Insertion, removal, and access operations safely execute concurrently by multiple threads in the ConcurrentSkipListSet

    //---------------- 5 ------------------
    /**
     * when the test fail, then it is a prof that there is a concurrency problem, that needs to be addressed in the implementation.
     * In other words, one failing test is enough to contradict the fact that the implementation is thread safe
     */

    //---------------- 6 ------------------
    /**
     * unlike the answer in question 5, the opposite scenario in which we assume that if the tests pass then the implementation
     * is thread safe does not hold water simply because we might be unlucky to hit the interleaving in which the implementation violate our assumption.
     */

    //---------------- 7 ------------------
    /**
     * Yes it is possible, a possible interleaving can occur when a thread read the value of the size, and at the same time another thread
     * add or remove an element from the set. as a result the size method in this case will return an aut dated value
     */

    //---------------- 8 ------------------
    /**
     * I am not sure if it is possible, because this test require the tester to trigger that interleaving and stop the process when that happens such that
     * the assertion will pass. Since the size will be eventually consistent with the number of operations on the set (when accessed in a mutual exclusive context)
     * making assertion that hits this interleaving will be very challenging and require the test to run many many times to hit is.
     */
}
